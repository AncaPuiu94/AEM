use(function() {
    return {
        logo: properties.get("logo/fileReference", ""),
        defaultMessage: properties.get("defaultMessage","")
    };
});
